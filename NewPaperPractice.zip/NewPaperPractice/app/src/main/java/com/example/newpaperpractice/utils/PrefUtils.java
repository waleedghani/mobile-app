package com.example.newpaperpractice.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.newpaperpractice.models.User;
import com.google.gson.Gson;

public class PrefUtils {
    private static final String pref_name = "My_Prefs";
    private SharedPreferences sharedPreferences;
    private  SharedPreferences.Editor editor;
    private static PrefUtils instance;

    public PrefUtils(Context context) {
        sharedPreferences = context.getSharedPreferences(pref_name, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public static PrefUtils getInstance(Context context) {
        if(instance == null) {
            instance = new PrefUtils(context);
        }
        return instance;
    }

    public boolean setUser(User user){
        Gson gson = new Gson();
        String userString = gson.toJson(user);
        editor.putString("user", userString);
        editor.apply();
        return true;
    }

    public User getUser() {
        Gson gson = new Gson();
        String userString = sharedPreferences.getString("user", "");
        return gson.fromJson(userString, User.class);
    }

    public boolean clearPrefs() {
        editor.remove("user");
        editor.apply();
        return true;
    }
}
