package com.example.newpaperpractice;

import android.app.ComponentCaller;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import pl.aprilapps.easyphotopicker.ChooserType;
import pl.aprilapps.easyphotopicker.EasyImage;
import pl.aprilapps.easyphotopicker.MediaFile;
import pl.aprilapps.easyphotopicker.MediaSource;

public class SignupActivity extends AppCompatActivity {

    CircleImageView profile_pic;
    ImageView camera_btn;
    TextView already_member_btn;
    TextInputEditText name, email, password;
    MaterialButton signup_btn;

    FirebaseAuth auth;
    FirebaseFirestore firestore;
    EasyImage easyImage;
    FirebaseStorage firebaseStorage;
    StorageReference reference;
    Uri ImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        reference = firebaseStorage.getReference();

        profile_pic = findViewById(R.id.profilePic);
        camera_btn = findViewById(R.id.cameraBtn);
        already_member_btn = findViewById(R.id.AlreadyMemberBtn);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        signup_btn = findViewById(R.id.signupBtn);

//        Glide.with(SignupActivity.this).load("https://cdn1.iconfinder.com/data/icons/user-pictures/100/male3-512.png").into(profile_pic);
        easyImage = new EasyImage.Builder(this)
                .setChooserTitle("Pick Image")
                .setChooserType(ChooserType.CAMERA_AND_GALLERY)
                .allowMultiple(false)
                .build();

        camera_btn.setOnClickListener(v -> {
            easyImage.openGallery(this);
        });

        already_member_btn.setOnClickListener(v -> {
            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        signup_btn.setOnClickListener(v -> {
            validateLogin();
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        easyImage.handleActivityResult(requestCode, resultCode, data, this, new EasyImage.Callbacks() {
            @Override
            public void onImagePickerError(@NonNull Throwable throwable, @NonNull MediaSource mediaSource) {

            }

            @Override
            public void onMediaFilesPicked(@NonNull MediaFile[] mediaFiles, @NonNull MediaSource mediaSource) {
                ImageUri = Uri.fromFile(mediaFiles[0].getFile());
                Glide.with(SignupActivity.this).load(ImageUri).into(profile_pic);
            }

            @Override
            public void onCanceled(@NonNull MediaSource mediaSource) {

            }
        });
    }

    public void validateLogin() {
        if(name.getText().toString().isEmpty()) {
            Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
        } else if(email.getText().toString().isEmpty()) {
            Toast.makeText(this, "Email field is required", Toast.LENGTH_SHORT).show();
        } else if(!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            Toast.makeText(this, "Email is invalid", Toast.LENGTH_SHORT).show();
        }else if(password.getText().toString().isEmpty()) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
        } else if(password.getText().length() < 8) {
            Toast.makeText(this, "Password should contain 8 characters", Toast.LENGTH_SHORT).show();
        } else {
            auth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
                @Override
                public void onSuccess(AuthResult authResult) {

                    String fileName = "Profile Pictures/" + authResult.getUser().getUid() + ".png";
                    StorageReference imageRef = reference.child(fileName);

                    if (ImageUri == null) {
                        Toast.makeText(SignupActivity.this, "Please select a profile image", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    imageRef.putFile(ImageUri).addOnSuccessListener(taskSnapshot -> {

                        imageRef.getDownloadUrl().addOnSuccessListener(uri -> {

                            Map<String, Object> map = new HashMap<>();
                            map.put("id", authResult.getUser().getUid());
                            map.put("name", name.getText().toString());
                            map.put("email", email.getText().toString());
                            map.put("password", password.getText().toString());
                            map.put("image", uri.toString());

                            firestore.collection("users").document(authResult.getUser().getUid()).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(SignupActivity.this, "Register Successfully", Toast.LENGTH_SHORT).show();
                                    email.setText("");
                                    password.setText("");
                                    name.setText("");
                                }
                            });

                        }).addOnFailureListener(e -> {
                            Toast.makeText(SignupActivity.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        });

                    }).addOnFailureListener(e -> {
                        Toast.makeText(SignupActivity.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    });

                }
            }).addOnFailureListener(this, new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(SignupActivity.this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}